# AstroNova — Android starter project

## Open it
1. Install Android Studio (a current stable release).
2. Open this folder in Android Studio.
3. Let Gradle sync finish. If prompted, install Android SDK Platform 35.
4. Run on an Android phone/tablet or emulator.

## What is implemented
- Kotlin + Jetpack Compose interface.
- Dark planetarium-style screen.
- Procedurally generated decorative star field.
- Illustrative constellation lines.
- Toggle constellation lines and labels UI.
- Drag gesture to explore the visual field.
- Time display and simple +/- 1 hour UI state.

## Important limitation
This is the first visual prototype, not yet an astronomy-accurate sky map. Star positions are decorative, constellation geometry is illustrative, and the time buttons currently change the displayed time offset only. It does not yet use GPS, compass, gyroscope, a real star catalogue, or accurate planet ephemerides.

## Next development milestones
1. Replace sample stars with a real catalogue (e.g. a curated Hipparcos subset).
2. Implement date/time + observer latitude/longitude transforms (equatorial to horizontal coordinates).
3. Add GPS and device orientation sensors with permissions and calibration.
4. Add accurate Sun, Moon, and planet positions.
5. Add search, object information cards, constellation names, and magnitude filters.
6. Optimize drawing and add deep-sky catalogue / Milky Way texture.

Package: `com.astronova.app`
