package com.astronova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF8AB4F8),
                    background = Color(0xFF050914),
                    surface = Color(0xFF101827)
                )
            ) {
                AstroNovaApp()
            }
        }
    }
}

@Composable
private fun AstroNovaApp() {
    var showConstellations by remember { mutableStateOf(true) }
    var showLabels by remember { mutableStateOf(true) }
    var azimuth by remember { mutableFloatStateOf(0f) }
    var altitude by remember { mutableFloatStateOf(0f) }
    var timeOffset by remember { mutableIntStateOf(0) }

    val timeLabel = remember(timeOffset) {
        val now = java.time.LocalDateTime.now().plusHours(timeOffset.toLong())
        now.format(java.time.format.DateTimeFormatter.ofPattern("dd MMM • HH:mm"))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050914))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("ASTRONOVA", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Gökyüzü keşifçisi • İlk prototip", color = Color(0xFF9AAAC4), fontSize = 12.sp)
            }
            Surface(color = Color(0xFF14243B), shape = RoundedCornerShape(20.dp)) {
                Text("ÖN SÜRÜM", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    color = Color(0xFF8AB4F8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InfoChip("GÖKYÜZÜ", "Canlı görünüm", Modifier.weight(1f))
            InfoChip("TARİH / SAAT", timeLabel, Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            StarField(
                showConstellations = showConstellations,
                showLabels = showLabels,
                azimuth = azimuth,
                altitude = altitude,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            azimuth += drag.x * 0.18f
                            altitude = (altitude - drag.y * 0.18f).coerceIn(-75f, 75f)
                        }
                    }
            )
            Column(
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("◉  Görüş yönü", color = Color(0xFFB8C9E8), fontSize = 12.sp)
                Text("Azimut: ${((azimuth % 360 + 360) % 360).toInt()}°",
                    color = Color.White, fontSize = 11.sp)
                Text("Kaydırarak keşfet", color = Color(0xFF7F91B0), fontSize = 10.sp)
            }
            Text(
                "GÖRSEL PROTOTİP • Henüz gerçek gökyüzü koordinatları değil",
                color = Color(0xFF8290A8),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { showConstellations = !showConstellations },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2A43))
            ) { Text(if (showConstellations) "Çizgileri gizle" else "Takımyıldızları") }
            Button(
                onClick = { showLabels = !showLabels },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2A43))
            ) { Text(if (showLabels) "İsimleri gizle" else "İsimleri göster") }
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Zamanı değiştir", color = Color(0xFFB8C9E8), fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { timeOffset -= 1 }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                    Text("−1 sa")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { timeOffset += 1 }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                    Text("+1 sa")
                }
            }
        }
    }
}

@Composable
private fun InfoChip(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xFF101827),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(title, color = Color(0xFF7F91B0), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private data class Star(val x: Float, val y: Float, val radius: Float, val brightness: Float)

private val stars: List<Star> = List(380) {
    val random = Random(it * 37 + 11)
    Star(
        x = random.nextFloat(),
        y = random.nextFloat(),
        radius = 0.5f + random.nextFloat() * 1.7f,
        brightness = 0.35f + random.nextFloat() * 0.65f
    )
}

@Composable
private fun StarField(
    showConstellations: Boolean,
    showLabels: Boolean,
    azimuth: Float,
    altitude: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF08152B), Color(0xFF050914), Color(0xFF10152A))
            )
        )

        // Decorative Milky Way haze for the first UI prototype.
        for (i in 0..22) {
            val y = h * (0.25f + i * 0.018f) + sin(i * 0.4f) * 18f
            drawLine(
                color = Color(0xFF273D60).copy(alpha = 0.035f),
                start = Offset(0f, y),
                end = Offset(w, y - h * 0.16f),
                strokeWidth = 18f + (i % 5) * 7f
            )
        }

        val dx = azimuth * 0.35f
        val dy = altitude * 0.35f
        stars.forEachIndexed { index, star ->
            val x = (star.x * w + dx * 2.2f).mod(w)
            val y = (star.y * h + dy * 2.2f).mod(h)
            val alpha = star.brightness
            drawCircle(
                color = if (index % 19 == 0) Color(0xFFFFDFA0).copy(alpha = alpha)
                        else Color(0xFFE3EDFF).copy(alpha = alpha),
                radius = star.radius,
                center = Offset(x, y)
            )
        }

        // A recognizable, illustrative Big Dipper pattern.
        val points = listOf(
            Offset(w * 0.18f, h * 0.30f),
            Offset(w * 0.27f, h * 0.34f),
            Offset(w * 0.35f, h * 0.31f),
            Offset(w * 0.42f, h * 0.37f),
            Offset(w * 0.51f, h * 0.40f),
            Offset(w * 0.58f, h * 0.34f),
            Offset(w * 0.65f, h * 0.29f)
        ).map { Offset((it.x + dx).mod(w), (it.y + dy).coerceIn(0f, h)) }

        if (showConstellations) {
            for (i in 0 until points.lastIndex) {
                drawLine(
                    color = Color(0xFF8AB4F8).copy(alpha = 0.72f),
                    start = points[i], end = points[i + 1], strokeWidth = 1.4f
                )
            }
        }
        points.forEachIndexed { i, point ->
            drawCircle(Color(0xFFFFE7B0), radius = if (i == 2) 3.4f else 2.4f, center = point)
        }

        // Horizon glow.
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0xFF1B3551).copy(alpha = 0.45f)),
                startY = h * 0.82f,
                endY = h
            ),
            topLeft = Offset(0f, h * 0.82f),
            size = androidx.compose.ui.geometry.Size(w, h * 0.18f)
        )
    }
}
